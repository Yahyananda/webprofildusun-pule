-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 08 Jan 2024 pada 16.38
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pulegedong`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `nama`, `username`, `password`) VALUES
(2, 'admin', 'admin', '0192023a7bbd73250516f069df18b500'),
(3, 'admin', 'admin1', 'e00cf25ad42683b3df678c61f42c6bda'),
(4, 'admin', 'admin2', 'c84258e9c39059a89ab77d846ddab909');

-- --------------------------------------------------------

--
-- Struktur dari tabel `artikel`
--

CREATE TABLE `artikel` (
  `id_artikel` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` text NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `artikel`
--

INSERT INTO `artikel` (`id_artikel`, `id_user`, `judul`, `gambar`, `tanggal`, `keterangan`, `status`) VALUES
(8, 11, 'Pendaftaran KPPS', 'kpps.jpeg', '2024-01-01', '<p>Pendaftaran Petugas Pemungutan Suara di Kalurahan Gedong</p>', '1'),
(12, 8, 'Pendaftaran Panwas', 'tpps.jpeg', '2024-01-01', '<p>Pendaftaran Panitia Pengawas pemungutan suara</p>', '1'),
(14, 14, 'Bahaya Kebakaran', 'bahaya kebakaran.png', '2024-01-01', '<p>Informasi Terkait waspada terhadap bencana kebakaran hutan karena cuaca ekstream</p>', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftar_warga`
--

CREATE TABLE `daftar_warga` (
  `id_warga` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `nik` varchar(20) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `daftar_warga`
--

INSERT INTO `daftar_warga` (`id_warga`, `id_user`, `nama`, `jenis_kelamin`, `alamat`, `nik`, `no_telp`, `email`, `gambar`) VALUES
(8, 1, 'Ibnu Yahya Dwinanda', 'Laki-Laki', 'Pule RT01', '2147483647', '0', 'Admin@gmail.com', 'kpps.jpeg'),
(11, 0, 'Nindi', 'Perempuan', 'Pule RT02', '2147483647', '2147483647', 'nindi@gmail.com', 'kerja bati.jpg'),
(14, 10, 'nina', 'Perempuan', 'Pule RT01', '3401101001030002', '082241514993', 'nina@gmail.com', 'bahaya kebakaran.png'),
(16, 11, 'Benu', 'Laki-Laki', 'Pule RT02', '34011010040006', '08768903345', 'benu@gmail.com', 'ktp-removebg-preview.png'),
(18, 2, 'jaja miharja', 'Laki-Laki', 'PULE RT01', '34001101001001', '089755672046', 'jaja@gmail.com', 'ktp-removebg-preview.png\r\n'),
(19, 3, 'marsya', 'perempuan', 'PULE RT 01', '340110100100103', '082241516678', 'marsya@gmail.com', 'ktp-removebg-preview.png\r\n'),
(20, 15, 'bibi', 'Perempuan', 'Pule RT01', '3401101001030002', '085899652024', 'bibi@gmail.com', 'ktp-removebg-preview.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_warga`
--

CREATE TABLE `data_warga` (
  `nama` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `identitas` varchar(255) NOT NULL,
  `ktp` varchar(255) NOT NULL,
  `no_telp` char(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `data_warga`
--

INSERT INTO `data_warga` (`nama`, `gender`, `alamat`, `identitas`, `ktp`, `no_telp`, `email`) VALUES
('', 'Gender', '', '', '', '', ''),
('adi', 'Laki-Laki', 'PULE RT 01', '', '', '082241567738', 'adi@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `event`
--

CREATE TABLE `event` (
  `id_event` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` text NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `event`
--

INSERT INTO `event` (`id_event`, `id_user`, `judul`, `gambar`, `tanggal`, `keterangan`, `status`) VALUES
(4, 8, 'Pule Gumregah', 'Pule Gumregah.jpg', '2023-12-28', '<p>pule pule</p>', '1'),
(5, 0, 'Gedong Festival', 'gedong festival.jpg', '2023-12-28', '<p>Gedong Festival</p>', '1'),
(7, 11, 'Rosulan', 'rasulan slider.jpg', '2024-01-01', '<p>Kegiatan Rosulan setiap satu tahun sekali</p>', '1'),
(8, 10, 'Semarak Kemerdekaan', '17an.jpg', '2024-01-02', '<p>Semarak 17 an di lingkungan pule</p>', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rutinan`
--

CREATE TABLE `rutinan` (
  `id_rutinan` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `rutinan`
--

INSERT INTO `rutinan` (`id_rutinan`, `id_admin`, `judul`, `gambar`, `tanggal`, `keterangan`, `status`) VALUES
(1, 3, 'Posyandu', 'posyandu.png', '2024-01-01', '<p>Kegiatan Posyandu Balita di Dusun Lingkungan Pule</p>', '1'),
(10, 4, 'Minggu Bersih', 'kerja bati.jpg', '2024-01-01', '\r\n<p>Minggu Bersih Merupakan Kegiatan berish bersih lingkungan di susun lingkungan pule yang dilakukan setiap minggu pagi </p>', '1'),
(12, 2, 'Ronda', 'ronda.jpg', '2024-01-01', '<p>Ronda merupakan kegiatan rutin setiap malam dan bergilir untuk menjaga keamana lingkungan masyarakat di dusun </p>', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama`, `alamat`, `username`, `password`, `foto`) VALUES
(2, 'Ibnu ', '', 'ibnu', '32a31fe046c83f7cff3c7c124e3bc02c', ''),
(3, '', '', 'nanda', '859a37720c27b9f70e11b79bab9318fe', ''),
(5, '', '', 'dwi', '7aa2602c588c05a93baf10128861aeb9', ''),
(8, '', '', 'yahya', '59202463fd4c312b063293b88f6063b2', ''),
(10, '', '', 'elis', 'eaba1bca7df38544439d482bb60ab916', ''),
(11, '', '', 'benu', '7b26b9a45cd0d36b1dee8b0c20a0537d', ''),
(12, 'elis', '089677905561', 'elis', 'eaba1bca7df38544439d482bb60ab916', ''),
(13, '', '1234567823', 'bounju', '25725334bdf1734355d4fd7c40d034e4', ''),
(14, 'Nindi', 'Pule RT01', 'nindi', 'c1689c1657c5946f292352e2b0188be4', ''),
(15, 'bibi', 'Pule RT01', 'bibi', '8115153332991997460b9f236e0da71a', ''),
(16, '', 'RT 02', 'benu', '7b26b9a45cd0d36b1dee8b0c20a0537d', ''),
(17, 'tono', 'Pule RT01', 'tono', '14d2d4119982cd6c68a566e523cb16ae', ''),
(18, 'admin', 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', ''),
(19, 'adi', 'Pule RT01', 'adi', 'c46335eb267e2e1cde5b017acb4cd799', ''),
(20, 'elis', 'Pule RT01', 'elis', 'eaba1bca7df38544439d482bb60ab916', '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id_artikel`),
  ADD UNIQUE KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `daftar_warga`
--
ALTER TABLE `daftar_warga`
  ADD PRIMARY KEY (`id_warga`),
  ADD UNIQUE KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id_event`),
  ADD UNIQUE KEY `id_admin` (`id_user`);

--
-- Indeks untuk tabel `rutinan`
--
ALTER TABLE `rutinan`
  ADD PRIMARY KEY (`id_rutinan`),
  ADD UNIQUE KEY `id_admin` (`id_admin`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id_artikel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `daftar_warga`
--
ALTER TABLE `daftar_warga`
  MODIFY `id_warga` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `event`
--
ALTER TABLE `event`
  MODIFY `id_event` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `rutinan`
--
ALTER TABLE `rutinan`
  MODIFY `id_rutinan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
